# Devops Example Project

# Project Dependencies
1. Node.js
2. Truffle
...
---
# Install Dependencies
1. use the cd command to navigate to the downloaded projects directory
2. Run the npm install command

# Run Project
1. use the cd command to navigate to the downloaded projects directory
2. Run the npm start command to run the project

***

